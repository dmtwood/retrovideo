package be.vdab.retrovideo.repositories;

import be.vdab.retrovideo.domain.Reservatie;

public interface ReservatiesRepository {
	void create(Reservatie reservatie);
}
