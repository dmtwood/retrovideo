package be.vdab.retrovideo.forms;

class MandjeForm {
	private long filmId;

	public long getFilmId() {
		return filmId;
	}

	public void setFilmId(int filmId) {
		this.filmId = filmId;
	}
	
	
}
