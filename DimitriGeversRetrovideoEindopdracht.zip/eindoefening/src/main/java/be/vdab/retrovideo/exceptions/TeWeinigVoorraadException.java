package be.vdab.retrovideo.exceptions;

public class TeWeinigVoorraadException extends FilmNietGevondenException {
    public TeWeinigVoorraadException(String message) {
        super(message);
    }
}
