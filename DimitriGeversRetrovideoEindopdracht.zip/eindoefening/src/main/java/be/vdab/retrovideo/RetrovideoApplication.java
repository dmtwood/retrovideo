package be.vdab.retrovideo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrovideoApplication {

    public static void main(String[] args) {
        SpringApplication.run(RetrovideoApplication.class, args);
    }

}
