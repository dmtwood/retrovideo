package be.vdab.retrovideo.exceptions;

public class FilmNietGevondenException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public FilmNietGevondenException(String message) {
		super(message);
	}

}
