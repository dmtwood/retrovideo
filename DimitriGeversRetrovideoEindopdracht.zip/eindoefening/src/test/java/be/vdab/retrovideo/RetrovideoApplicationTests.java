package be.vdab.retrovideo;

import org.junit.jupiter.api.Test;


class RetrovideoApplicationTests {

    @Test
    void contextLoads() {
    }

}
