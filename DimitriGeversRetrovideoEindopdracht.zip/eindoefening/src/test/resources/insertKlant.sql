insert into klanten(familienaam, voornaam, straatNummer, postcode, gemeente)
values('testfamilienaam','testvoornaam','teststraatNummer', 'pc', 'testgemeente');